

******* Files ********

GaussianBlur.py   ---->  Python program that takes image input and outputs smoothen versions of it.

GB_Results.txt    ---->  Contains the information about the output images obtained by applying GaussianBlur on input image.

cornerHarris.py   ---->  Python program that takes image input and outputs images containing edges marked with red squares.

HCD_Results.txt   ---->  Contains the information about the output images obtained by apply Harris Corner Detection on input image.



****** Folders *******

GaussianBlur      ---->  Contains multiple output versions of inputted image to GaussianBlur.py

cornerHarris      ---->  Contains multiple output versions of inputted image to Harris Corner Detection i.e., cornerHarris.py

CannyEdge         ---->  Contains the files required to detect edge by CannyEdge dectection method.
