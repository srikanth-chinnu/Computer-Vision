Mainly the assignment consists of 3 files

image_stitching.py
Superimpose.py
final_output.py

run individual files in order as described above as follows:

python image_stitching.py images_paths/images_paths.txt
python Superimpose.py <imagepath> <imagepath>
python final_output.py output_image/stitched_image.jpg


final output is:
stitched_rect_image.jpg
